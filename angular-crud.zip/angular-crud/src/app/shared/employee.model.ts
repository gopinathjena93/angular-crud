export class Employee {
    EmployeeID: number;
    FullName: string;
    EMPCode: string;
    Mobile: string;
    Position: string;
}
