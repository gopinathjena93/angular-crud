<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\EmployeeModel;
use Illuminate\Support\Facades\DB;
class EmployeeController extends Controller {
    public function fetch() {
        $products = EmployeeModel::all()->toArray();
        return $products;
    }

    public function single($id) {
        $products = EmployeeModel::find($id)->toArray();        
        return $products;
    }

    public function update(Request $request, $id)
    {
        //print_r($request);   

        return EmployeeModel::where('EmployeeID', '=', $id)
        ->update(['FullName' => $request->FullName,
                'Position' => $request->Position,
                'EMPCode' => $request->EMPCode,
                'Mobile' => $request->Mobile]);
        
    }

    public function add(Request $request)
    {
        //print_r($request);       
        $employee = new EmployeeModel;
        $employee->FullName = $request->FullName;
        $employee->Position = $request->Position;
        $employee->EMPCode = $request->EMPCode;
        $employee->Mobile = $request->Mobile;        
        $employee->save();       
        return ["status" => "success" ]; 
    }

    public function delete($id)
    {
        $employee=EmployeeModel::find($id);
        $employee->delete(); 
        return ["status" => "success" ];            
    }

   

    public function example() {

        $url = route('product-update');

        echo "<pre>"; print_r($url); echo "</pre>";

        //dd($url);


        $products = ProductModel::all();

        //$product = ProductModel::where('id',1)->orWhereNull('details')->update(['name' => 'gopinath jena new','details' => '444444 44444 4444']);
        //DB::enableQueryLog();
        //dd(DB::getQueryLog());
        //$product->name = "Gopinath Jena";
        //$product->details = null;
        //$product->save();
        //echo "<pre>"; print_r($products); echo "</pre>";

        //ProductModel::where('id', 1)->update(['name' => 'gopinath jena csm']);
        //echo "hiiiiiiiii";

        
        
    }
}
