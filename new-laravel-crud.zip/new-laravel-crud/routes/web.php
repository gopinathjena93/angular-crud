<?php


Route::get('/product/fetch','ProductController@fetch');
Route::get('/product/update','ProductController@update')->name('product-update');

Route::get('/', function () {    
    return view('welcome');
});
